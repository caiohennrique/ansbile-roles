The default directory to place BIRT runtime log files.
